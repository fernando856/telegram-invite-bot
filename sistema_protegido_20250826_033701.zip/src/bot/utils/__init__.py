# Utilitários do Bot

